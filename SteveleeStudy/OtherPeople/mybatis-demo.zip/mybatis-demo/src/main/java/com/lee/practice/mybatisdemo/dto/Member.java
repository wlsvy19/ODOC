package com.lee.practice.mybatisdemo.dto;

public class Member {

    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
