package kr.co.exam;

import org.springframework.stereotype.Service;

public interface InfoService {
	
	
	UserVO check_id(UserVO user);
	
	

}
