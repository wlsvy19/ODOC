package com.fif.app.finalexam;

import java.util.List;

public interface UserService {
    public List<UserDTO> selectUser() throws Exception;

}
