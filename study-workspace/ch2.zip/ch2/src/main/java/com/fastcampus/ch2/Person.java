package com.fastcampus.ch2;

public class Person { 
    private Car car = new Car(); 
    public  Car getCar() { return car; }
}  

