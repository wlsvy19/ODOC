export const FAQsData = [
	{
		id: 1,
		question: 'Will I be charged now for?',
		answer:
			'Vestibulum pulvinar est at erat laoreet fringilla. Nullam imperdiet, augue non vestibulum triuam quam, at maximus ex mauris a felis.'
	},
	{
		id: 2,
		question: 'How does a subscription work?',
		answer:
			'Donec tempus imperdiet libero quis ultricies. Donec nunc nisi, imperdiet nec porta ultrices, accumsan a nibh.'
	},
	{
		id: 3,
		question: 'Can I cancel anytime?',
		answer:
			'Yes, Pellentesque habitant morbi tristique senectus et netus fficitur eget lacus eu, gravida blandit sem. Duis aliquam convallis tempor.'
	},
	{
		id: 4,
		question: 'How long is my personal?',
		answer:
			'Aliquam vel sodales est. Mauris eu dignissim dolor. Praesent scelerisque dolor risus, quis viverra interdum turpis tincidunt interdum.'
	},
	{
		id: 5,
		question: 'What are Multisite plan?',
		answer:
			'Quisque accumsan odio sed congue u eleifend est porttitor nisi lobortis, sit aget dolor rhoncus tincidunt vel a mauris.'
	},
	{
		id: 6,
		question: 'Are the files downloadable?',
		answer:
			'Pellentesque habitant morbi tristique senectus et netus et malesuada fitur eget lacus eu, gravida blandit sem.'
	}
];
export default FAQsData;
