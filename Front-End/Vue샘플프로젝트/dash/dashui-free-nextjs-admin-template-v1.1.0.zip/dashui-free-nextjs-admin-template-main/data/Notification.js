const Notification = [
	{
		id: 1,
		sender: 'Rishi Chopra',
		message: `Mauris blandit erat id nunc blandit, ac eleifend dolor pretium.`
	},
	{
		id: 2,
		sender: 'Neha Kannned',
		message: `Proin at elit vel est condimentum elementum id in ante. Maecenas et sapien metus.`
	},
	{
		id: 3,
		sender: 'Nirmala Chauhan',
		message: `Morbi maximus urna lobortis elit sollicitudin sollicitudieget elit vel pretium.`
	},
	{
		id: 4,
		sender: 'Sina Ray',
		message: `Sed aliquam augue sit amet mauris volutpat hendrerit sed nunc eu diam.`
	}
];

export default Notification;
