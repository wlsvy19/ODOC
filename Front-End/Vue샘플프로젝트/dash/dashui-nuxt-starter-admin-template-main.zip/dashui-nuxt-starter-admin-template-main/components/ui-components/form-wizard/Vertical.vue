<script setup>
import { Vertical } from "./__code";
</script>

<template>
  <div id="vertical">
    <GlobalsIntro title="Vertical" />
    <GlobalsCodePre :code="Vertical"> ds </GlobalsCodePre>
  </div>
</template>
