<script setup>
import { Icons } from "./__code";
</script>

<template>
  <div id="icons">
    <GlobalsIntro title="Icons" />
    <GlobalsCodePre :code="Icons"> ds </GlobalsCodePre>
  </div>
</template>
