<script setup>
import { Default } from "./__code";
</script>

<template>
  <div id="default">
    <GlobalsIntro title="Default">
      Dividers in their simplest form display a horizontal line.
    </GlobalsIntro>
    <GlobalsCodePre :code="Default">
      <v-divider />
    </GlobalsCodePre>
  </div>
</template>
