export const Basic = ``
