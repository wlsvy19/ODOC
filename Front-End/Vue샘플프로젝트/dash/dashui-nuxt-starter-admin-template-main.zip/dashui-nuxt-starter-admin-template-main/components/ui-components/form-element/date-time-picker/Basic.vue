<script setup>
import { Basic } from "./__code";
</script>

<template>
  <div id="basic">
    <GlobalsIntro title="Basic" />

    <GlobalsCodePre :code="Basic"> Date & TIme // </GlobalsCodePre>
  </div>
</template>
