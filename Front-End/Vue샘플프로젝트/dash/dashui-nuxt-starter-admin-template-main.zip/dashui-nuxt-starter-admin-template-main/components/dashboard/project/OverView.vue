<template>
  <div class="project-over-view pb-5">
    <v-row>
      <v-col cols="12" md="6" lg="3">
        <v-card class="card-lift">
          <v-card-item>
            <div class="d-flex justify-space-between align-center">
              <h4 class="text-h4">Projects</h4>
              <div class="soft-bg-primary size-10">
                <v-icon icon="tabler-briefcase" size="24" color="primary" />
              </div>
            </div>
            <div class="mt-3 mb-1">
              <h3 class="text-h1">18</h3>
            </div>
            <p class="text-body-1">2 Completed</p>
          </v-card-item>
        </v-card>
      </v-col>

      <v-col cols="12" md="6" lg="3">
        <v-card class="card-lift">
          <v-card-item>
            <div class="d-flex justify-space-between align-center">
              <h4 class="text-h4">Active Task</h4>
              <div class="soft-bg-primary size-10">
                <v-icon icon="tabler-list" size="24" color="primary" />
              </div>
            </div>
            <div class="mt-3 mb-1">
              <h3 class="text-h1">132</h3>
            </div>
            <p class="text-body-1">28 Completed</p>
          </v-card-item>
        </v-card>
      </v-col>

      <v-col cols="12" md="6" lg="3">
        <v-card class="card-lift">
          <v-card-item>
            <div class="d-flex justify-space-between align-center">
              <h4 class="text-h4">Teams</h4>
              <div class="soft-bg-primary size-10">
                <v-icon icon="tabler-users" size="24" color="primary" />
              </div>
            </div>
            <div class="mt-3 mb-1">
              <h3 class="text-h1">12</h3>
            </div>
            <p class="text-body-1">1 Completed</p>
          </v-card-item>
        </v-card>
      </v-col>

      <v-col cols="12" md="6" lg="3">
        <v-card class="card-lift">
          <v-card-item>
            <div class="d-flex justify-space-between align-center">
              <h4 class="text-h4">Productivity</h4>
              <div class="soft-bg-primary size-10">
                <v-icon icon="tabler-target" size="24" color="primary" />
              </div>
            </div>
            <div class="mt-3 mb-1">
              <h3 class="text-h1">76%</h3>
            </div>
            <p class="text-body-1">
              <span class="text-success">5% </span>
              Completed
            </p>
          </v-card-item>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>
